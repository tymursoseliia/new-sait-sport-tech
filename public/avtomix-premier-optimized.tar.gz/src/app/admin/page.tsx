'use client';

import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Car, MessageSquare, Phone, Settings, Download, Copy, Check } from 'lucide-react';
import { CARS } from '@/data/cars';
import { REVIEWS } from '@/data/reviews';
import { CONTACTS } from '@/config/contacts';

export default function AdminPanel() {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const copyToClipboard = async (text: string, section: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedSection(section);
      setTimeout(() => setCopiedSection(null), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const generateCarCode = () => {
    return `{
  id: ${CARS.length + 1},
  make: 'Марка',
  model: 'Модель',
  year: 2024,
  mileage: 50000,
  fuel: 'Бензин',
  transmission: 'Автомат',
  body: 'Седан',
  price: 2000000,
  imageUrl: 'https://...',
  status: 'available', // 'available' или 'order'
  slug: 'marka-model-2024',
  originCountry: 'Германия',
}`;
  };

  const generateReviewCode = () => {
    return `{
  id: ${REVIEWS.length + 1},
  name: 'Имя К.',
  city: 'Москва',
  car: 'Марка Модель',
  brand: 'Марка',
  date: '2024-11-${new Date().getDate()}',
  rating: 5,
  text: 'Текст отзыва...',
  imageUrl: 'https://...',
  country: 'Германия',
  verified: true,
  purchaseVerified: true,
}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-zinc-50 to-zinc-100 py-8">
      <div className="container-custom max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2 text-zinc-900">Admin Panel</h1>
          <p className="text-zinc-600">Управление данными сайта AVTOMIX PREMIER</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="p-6 bg-white border-zinc-200">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-primary/10 rounded-lg">
                <Car className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-zinc-600">Автомобилей</p>
                <p className="text-2xl font-bold text-zinc-900">{CARS.length}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-white border-zinc-200">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-green-500/10 dark:bg-green-500/20 rounded-lg">
                <MessageSquare className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-zinc-600">Отзывов</p>
                <p className="text-2xl font-bold text-zinc-900">{REVIEWS.length}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-white border-zinc-200">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-purple-50 rounded-lg">
                <Phone className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-zinc-600">Контакты</p>
                <p className="text-2xl font-bold text-zinc-900">Активны</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="cars" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="cars">
              <Car className="w-4 h-4 mr-2" />
              Автомобили
            </TabsTrigger>
            <TabsTrigger value="reviews">
              <MessageSquare className="w-4 h-4 mr-2" />
              Отзывы
            </TabsTrigger>
            <TabsTrigger value="contacts">
              <Phone className="w-4 h-4 mr-2" />
              Контакты
            </TabsTrigger>
          </TabsList>

          {/* Cars Tab */}
          <TabsContent value="cars" className="space-y-6">
            <Card className="p-6 bg-white border-zinc-200">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-zinc-900">Автомобили</h2>
                  <p className="text-sm text-zinc-600 mt-1">Всего в каталоге: {CARS.length} шт.</p>
                </div>
                <Button
                  variant="outline"
                  onClick={() => copyToClipboard(generateCarCode(), 'car-template')}
                >
                  {copiedSection === 'car-template' ? (
                    <><Check className="w-4 h-4 mr-2" />Скопировано</>
                  ) : (
                    <><Copy className="w-4 h-4 mr-2" />Шаблон нового авто</>
                  )}
                </Button>
              </div>

              <div className="space-y-4">
                {CARS.map((car) => (
                  <Card key={car.id} className="p-4 border-zinc-200 hover:shadow-md transition-shadow">
                    <div className="flex items-start gap-4">
                      <img
                        src={car.imageUrl}
                        alt={`${car.make} ${car.model}`}
                        className="w-24 h-24 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="text-lg font-bold text-zinc-900">
                              {car.make} {car.model}
                            </h3>
                            <p className="text-sm text-zinc-600">
                              {car.year} • {car.mileage.toLocaleString('ru-RU')} км • {car.fuel}
                            </p>
                          </div>
                          <Badge variant={car.status === 'available' ? 'default' : 'secondary'}>
                            {car.status === 'available' ? 'В наличии' : 'Под заказ'}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4">
                          <p className="text-xl font-bold text-primary">
                            {car.price.toLocaleString('ru-RU')} ₽
                          </p>
                          <p className="text-sm text-zinc-500">ID: {car.id}</p>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              <div className="mt-6 p-4 bg-zinc-50 rounded-lg border border-zinc-200">
                <h3 className="font-semibold text-zinc-900 mb-2">📝 Как добавить новое авто:</h3>
                <ol className="text-sm text-zinc-600 space-y-1 ml-4 list-decimal">
                  <li>Откройте файл <code className="px-2 py-1 bg-muted rounded">src/data/cars.ts</code></li>
                  <li>Скопируйте шаблон кнопкой выше</li>
                  <li>Добавьте объект в массив <code className="px-2 py-1 bg-muted rounded">CARS</code></li>
                  <li>Заполните все поля (ID должен быть уникальным)</li>
                  <li>Сохраните файл и задеплойте</li>
                </ol>
              </div>
            </Card>
          </TabsContent>

          {/* Reviews Tab */}
          <TabsContent value="reviews" className="space-y-6">
            <Card className="p-6 bg-white border-zinc-200">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-zinc-900">Отзывы клиентов</h2>
                  <p className="text-sm text-zinc-600 mt-1">Всего отзывов: {REVIEWS.length} шт.</p>
                </div>
                <Button
                  variant="outline"
                  onClick={() => copyToClipboard(generateReviewCode(), 'review-template')}
                >
                  {copiedSection === 'review-template' ? (
                    <><Check className="w-4 h-4 mr-2" />Скопировано</>
                  ) : (
                    <><Copy className="w-4 h-4 mr-2" />Шаблон нового отзыва</>
                  )}
                </Button>
              </div>

              <div className="space-y-4">
                {REVIEWS.map((review) => (
                  <Card key={review.id} className="p-4 border-zinc-200">
                    <div className="flex items-start gap-4">
                      {review.imageUrl && (
                        <img
                          src={review.imageUrl}
                          alt={review.car}
                          className="w-20 h-20 object-cover rounded-lg"
                        />
                      )}
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="font-bold text-zinc-900">{review.name}</h3>
                            <p className="text-sm text-zinc-600">{review.car} • {review.city}</p>
                          </div>
                          <div className="flex gap-1">
                            {[...Array(5)].map((_, i) => (
                              <span key={i} className={i < review.rating ? 'text-yellow-500' : 'text-zinc-300'}>
                                ★
                              </span>
                            ))}
                          </div>
                        </div>
                        <p className="text-sm text-zinc-600 line-clamp-2">{review.text}</p>
                        <div className="flex items-center gap-3 mt-2">
                          <p className="text-xs text-zinc-500">ID: {review.id}</p>
                          {review.verified && (
                            <Badge variant="outline" className="text-xs">Проверено</Badge>
                          )}
                          {review.highlights?.savings && (
                            <Badge variant="secondary" className="text-xs">
                              Экономия: {review.highlights.savings}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              <div className="mt-6 p-4 bg-zinc-50 rounded-lg border border-zinc-200">
                <h3 className="font-semibold text-zinc-900 mb-2">📝 Как добавить новый отзыв:</h3>
                <ol className="text-sm text-zinc-600 space-y-1 ml-4 list-decimal">
                  <li>Откройте файл <code className="px-2 py-1 bg-muted rounded">src/data/reviews.ts</code></li>
                  <li>Скопируйте шаблон кнопкой выше</li>
                  <li>Добавьте объект в массив <code className="px-2 py-1 bg-muted rounded">REVIEWS</code></li>
                  <li>Заполните все обязательные поля</li>
                  <li>Сохраните файл и задеплойте</li>
                </ol>
              </div>
            </Card>
          </TabsContent>

          {/* Contacts Tab */}
          <TabsContent value="contacts" className="space-y-6">
            <Card className="p-6 bg-white border-zinc-200">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-zinc-900">Контактная информация</h2>
                  <p className="text-sm text-zinc-600 mt-1">Используется на всём сайте</p>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                {/* Основная информация */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-zinc-900">Основная информация</h3>

                  <div className="p-4 bg-zinc-50 rounded-lg">
                    <p className="text-xs text-zinc-500 mb-1">Название компании</p>
                    <p className="font-semibold text-zinc-900">{CONTACTS.companyName}</p>
                  </div>

                  <div className="p-4 bg-zinc-50 rounded-lg">
                    <p className="text-xs text-zinc-500 mb-1">Юр. название</p>
                    <p className="font-semibold text-zinc-900">{CONTACTS.legalName}</p>
                  </div>

                  <div className="p-4 bg-zinc-50 rounded-lg">
                    <p className="text-xs text-zinc-500 mb-1">Год основания</p>
                    <p className="font-semibold text-zinc-900">{CONTACTS.foundingYear}</p>
                  </div>
                </div>

                {/* Контакты */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-zinc-900">Контактные данные</h3>

                  <div className="p-4 bg-zinc-50 rounded-lg">
                    <p className="text-xs text-zinc-500 mb-1">Основной телефон</p>
                    <a href={CONTACTS.phoneHref} className="font-semibold text-primary hover:underline">
                      {CONTACTS.phone}
                    </a>
                  </div>

                  <div className="p-4 bg-zinc-50 rounded-lg">
                    <p className="text-xs text-zinc-500 mb-1">Дополнительный телефон</p>
                    <a href={CONTACTS.phoneSecondaryHref} className="font-semibold text-primary hover:underline">
                      {CONTACTS.phoneSecondary}
                    </a>
                  </div>

                  <div className="p-4 bg-zinc-50 rounded-lg">
                    <p className="text-xs text-zinc-500 mb-1">Email</p>
                    <a href={CONTACTS.emailHref} className="font-semibold text-primary hover:underline">
                      {CONTACTS.email}
                    </a>
                  </div>

                  <div className="p-4 bg-zinc-50 rounded-lg">
                    <p className="text-xs text-zinc-500 mb-1">Поддержка</p>
                    <a href={CONTACTS.emailSupportHref} className="font-semibold text-primary hover:underline">
                      {CONTACTS.emailSupport}
                    </a>
                  </div>
                </div>

                {/* Адрес */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-zinc-900">Адрес</h3>

                  <div className="p-4 bg-zinc-50 rounded-lg">
                    <p className="text-xs text-zinc-500 mb-1">Полный адрес</p>
                    <p className="font-semibold text-zinc-900">{CONTACTS.address}</p>
                  </div>

                  <div className="p-4 bg-zinc-50 rounded-lg">
                    <p className="text-xs text-zinc-500 mb-1">Город</p>
                    <p className="font-semibold text-zinc-900">{CONTACTS.city}</p>
                  </div>

                  <div className="p-4 bg-zinc-50 rounded-lg">
                    <p className="text-xs text-zinc-500 mb-1">Регион</p>
                    <p className="font-semibold text-zinc-900">{CONTACTS.region}</p>
                  </div>

                  <div className="p-4 bg-zinc-50 rounded-lg">
                    <p className="text-xs text-zinc-500 mb-1">Индекс</p>
                    <p className="font-semibold text-zinc-900">{CONTACTS.postalCode}</p>
                  </div>
                </div>

                {/* Мессенджеры и соцсети */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-zinc-900">Мессенджеры</h3>

                  <div className="p-4 bg-zinc-50 rounded-lg">
                    <p className="text-xs text-zinc-500 mb-1">WhatsApp</p>
                    <a
                      href={CONTACTS.whatsapp}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="font-semibold text-green-600 hover:underline"
                    >
                      {CONTACTS.whatsappNumber}
                    </a>
                  </div>

                  <div className="p-4 bg-zinc-50 rounded-lg">
                    <p className="text-xs text-zinc-500 mb-1">Telegram</p>
                    <a
                      href={CONTACTS.telegram}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="font-semibold text-blue-600 hover:underline"
                    >
                      {CONTACTS.telegramUsername}
                    </a>
                  </div>

                  <div className="p-4 bg-zinc-50 rounded-lg">
                    <p className="text-xs text-zinc-500 mb-1">Сайт</p>
                    <a
                      href={CONTACTS.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="font-semibold text-primary hover:underline"
                    >
                      {CONTACTS.website}
                    </a>
                  </div>
                </div>
              </div>

              <div className="mt-6 p-4 bg-zinc-50 rounded-lg border border-zinc-200">
                <h3 className="font-semibold text-zinc-900 mb-2">📝 Как изменить контакты:</h3>
                <ol className="text-sm text-zinc-600 space-y-1 ml-4 list-decimal">
                  <li>Откройте файл <code className="px-2 py-1 bg-muted rounded">src/config/contacts.ts</code></li>
                  <li>Найдите нужное поле в объекте <code className="px-2 py-1 bg-muted rounded">CONTACTS</code></li>
                  <li>Измените значение</li>
                  <li>Сохраните файл и задеплойте</li>
                  <li>Изменения применятся автоматически на всём сайте!</li>
                </ol>
              </div>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Footer Info */}
        <Card className="mt-8 p-6 bg-white border-zinc-200">
          <div className="flex items-start gap-4">
            <Settings className="w-6 h-6 text-zinc-400 flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-semibold text-zinc-900 mb-2">ℹ️ Важная информация</h3>
              <ul className="text-sm text-zinc-600 space-y-1">
                <li>• Эта панель показывает текущие данные из файлов проекта</li>
                <li>• Для редактирования откройте соответствующие файлы в редакторе кода</li>
                <li>• После изменений не забудьте сохранить и задеплоить проект</li>
                <li>• Подробные инструкции доступны в файле <code className="px-2 py-1 bg-muted rounded">.same/data-management-guide.md</code></li>
              </ul>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}

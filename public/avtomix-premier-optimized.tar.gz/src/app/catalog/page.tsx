'use client';

import { useState, useMemo } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { CARS, type CarItem } from '@/data/cars';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetClose,
} from '@/components/ui/sheet';
import Breadcrumbs from '@/components/Breadcrumbs';
import { useLanguage } from '@/contexts/LanguageContext';
import { Filter, X } from 'lucide-react';

export default function CatalogPage() {
  const { t } = useLanguage();
  const [filters, setFilters] = useState({
    brand: '',
    year: '',
    priceFrom: '',
    priceTo: '',
    body: '',
    status: '',
  });
  const [sortBy, setSortBy] = useState('price-asc');
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  // Получение уникальных значений для фильтров
  const uniqueBrands = useMemo(() => {
    return Array.from(new Set(CARS.map(car => car.make))).sort();
  }, []);

  const uniqueBodyTypes = useMemo(() => {
    return Array.from(new Set(CARS.map(car => car.body))).sort();
  }, []);

  // Фильтрация автомобилей
  const filteredCars = useMemo(() => {
    return CARS.filter((car) => {
      // Фильтр по марке
      if (filters.brand && filters.brand !== 'all') {
        if (car.make.toLowerCase() !== filters.brand.toLowerCase()) {
          return false;
        }
      }

      // Фильтр по году
      if (filters.year && filters.year !== 'all') {
        if (car.year < parseInt(filters.year)) {
          return false;
        }
      }

      // Фильтр по цене от
      if (filters.priceFrom) {
        if (car.price < parseInt(filters.priceFrom)) {
          return false;
        }
      }

      // Фильтр по цене до
      if (filters.priceTo) {
        if (car.price > parseInt(filters.priceTo)) {
          return false;
        }
      }

      // Фильтр по типу кузова
      if (filters.body && filters.body !== 'all') {
        const bodyMap: { [key: string]: string } = {
          'sedan': 'Седан',
          'suv': 'Внедорожник',
          'wagon': 'Универсал',
          'coupe': 'Купе',
        };
        if (car.body !== bodyMap[filters.body]) {
          return false;
        }
      }

      // Фильтр по статусу
      if (filters.status && filters.status !== 'all') {
        if (car.status !== filters.status) {
          return false;
        }
      }

      return true;
    });
  }, [filters]);

  // Сортировка автомобилей
  const sortedCars = useMemo(() => {
    const sorted = [...filteredCars];

    switch (sortBy) {
      case 'price-asc':
        return sorted.sort((a, b) => a.price - b.price);
      case 'price-desc':
        return sorted.sort((a, b) => b.price - a.price);
      case 'year-desc':
        return sorted.sort((a, b) => b.year - a.year);
      case 'mileage-asc':
        return sorted.sort((a, b) => a.mileage - b.mileage);
      default:
        return sorted;
    }
  }, [filteredCars, sortBy]);

  const resetFilters = () => {
    setFilters({
      brand: '',
      year: '',
      priceFrom: '',
      priceTo: '',
      body: '',
      status: '',
    });
  };

  // Получить активные фильтры для резюме
  const getActiveFilters = () => {
    const active = [];
    if (filters.brand && filters.brand !== 'all') {
      active.push(filters.brand);
    }
    if (filters.year && filters.year !== 'all') {
      active.push(`от ${filters.year} г.`);
    }
    if (filters.priceFrom) {
      active.push(`от ${parseInt(filters.priceFrom).toLocaleString()} ₽`);
    }
    if (filters.priceTo) {
      active.push(`до ${parseInt(filters.priceTo).toLocaleString()} ₽`);
    }
    if (filters.body && filters.body !== 'all') {
      active.push(filters.body);
    }
    if (filters.status && filters.status !== 'all') {
      active.push(filters.status === 'available' ? 'В наличии' : 'Под заказ');
    }
    return active;
  };

  const activeFilters = getActiveFilters();

  // Компонент фильтров (переиспользуется в десктопе и bottom-sheet)
  const FilterForm = () => (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
      {/* Марка */}
      <div className="space-y-2">
        <Label className="text-sm font-medium">{t('catalogPage.brand')}</Label>
        <Select
          value={filters.brand}
          onValueChange={(value) => setFilters({ ...filters, brand: value })}
        >
          <SelectTrigger>
            <SelectValue placeholder={t('catalogPage.allBrands')} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t('catalogPage.allBrands')}</SelectItem>
            {uniqueBrands.map((brand) => (
              <SelectItem key={brand} value={brand.toLowerCase()}>
                {brand}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Год */}
      <div className="space-y-2">
        <Label className="text-sm font-medium">{t('catalogPage.yearFrom')}</Label>
        <Select
          value={filters.year}
          onValueChange={(value) => setFilters({ ...filters, year: value })}
        >
          <SelectTrigger>
            <SelectValue placeholder={t('catalogPage.any')} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t('catalogPage.any')}</SelectItem>
            <SelectItem value="2023">2023</SelectItem>
            <SelectItem value="2022">2022</SelectItem>
            <SelectItem value="2021">2021</SelectItem>
            <SelectItem value="2020">2020</SelectItem>
            <SelectItem value="2019">2019</SelectItem>
            <SelectItem value="2018">2018</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Цена от */}
      <div className="space-y-2">
        <Label className="text-sm font-medium">{t('catalogPage.priceFrom')}</Label>
        <Input
          type="number"
          placeholder={t('catalogPage.priceFromPlaceholder')}
          value={filters.priceFrom}
          onChange={(e) => setFilters({ ...filters, priceFrom: e.target.value })}
        />
      </div>

      {/* Цена до */}
      <div className="space-y-2">
        <Label className="text-sm font-medium">{t('catalogPage.priceTo')}</Label>
        <Input
          type="number"
          placeholder={t('catalogPage.priceToPlaceholder')}
          value={filters.priceTo}
          onChange={(e) => setFilters({ ...filters, priceTo: e.target.value })}
        />
      </div>

      {/* Тип кузова */}
      <div className="space-y-2">
        <Label className="text-sm font-medium">{t('catalogPage.bodyType')}</Label>
        <Select
          value={filters.body}
          onValueChange={(value) => setFilters({ ...filters, body: value })}
        >
          <SelectTrigger>
            <SelectValue placeholder={t('catalogPage.any')} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t('catalogPage.any')}</SelectItem>
            <SelectItem value="sedan">{t('catalogPage.sedan')}</SelectItem>
            <SelectItem value="suv">{t('catalogPage.suv')}</SelectItem>
            <SelectItem value="wagon">{t('catalogPage.wagon')}</SelectItem>
            <SelectItem value="coupe">{t('catalogPage.coupe')}</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Статус */}
      <div className="space-y-2">
        <Label className="text-sm font-medium">{t('catalogPage.status')}</Label>
        <Select
          value={filters.status}
          onValueChange={(value) => setFilters({ ...filters, status: value })}
        >
          <SelectTrigger>
            <SelectValue placeholder={t('catalogPage.all')} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t('catalogPage.all')}</SelectItem>
            <SelectItem value="available">{t('catalogPage.inStock')}</SelectItem>
            <SelectItem value="order">{t('catalogPage.onOrder')}</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col">
      <Breadcrumbs items={[{ label: t('nav.catalog') }]} />

      {/* Hero секция */}
      <section className="bg-gradient-to-br from-muted/50 to-muted py-6 md:py-24">
        <div className="container-custom px-4">
          <div className="max-w-3xl">
            <h1 className="text-2xl leading-tight md:text-5xl font-bold mb-3 md:mb-6">{t('catalogPage.title')}</h1>
            <p className="text-sm md:text-xl text-muted-foreground">
              {t('catalogPage.subtitle')}
            </p>
          </div>
        </div>
      </section>

      {/* Фильтры и каталог */}
      <section className="py-4 md:py-24 bg-background">
        <div className="container-custom px-4">
          {/* ДЕСКТОП: Фильтры в карточке */}
          <Card className="hidden md:block p-4 md:p-6 mb-10">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold">{t('catalogPage.filters')}</h2>
              <Button variant="ghost" size="sm" onClick={resetFilters}>
                {t('catalogPage.resetAll')}
              </Button>
            </div>
            <FilterForm />
          </Card>

          {/* МОБАЙЛ: Компактная панель фильтров */}
          <div className="md:hidden mb-4">
            <div className="flex items-center gap-2 mb-3">
              {/* Кнопка фильтров */}
              <Sheet open={isFilterOpen} onOpenChange={setIsFilterOpen}>
                <SheetTrigger asChild>
                  <Button variant="outline" className="flex-1 gap-2">
                    <Filter className="w-4 h-4" />
                    Фильтры
                    {activeFilters.length > 0 && (
                      <Badge variant="secondary" className="ml-1 px-1.5 py-0 text-xs">
                        {activeFilters.length}
                      </Badge>
                    )}
                  </Button>
                </SheetTrigger>

                {/* Селект сортировки */}
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="flex-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="price-asc">{t('catalogPage.sortPriceAsc')}</SelectItem>
                    <SelectItem value="price-desc">{t('catalogPage.sortPriceDesc')}</SelectItem>
                    <SelectItem value="year-desc">{t('catalogPage.sortYearDesc')}</SelectItem>
                    <SelectItem value="mileage-asc">{t('catalogPage.sortMileageAsc')}</SelectItem>
                  </SelectContent>
                </Select>

                {/* Bottom Sheet с фильтрами */}
                <SheetContent side="bottom" className="h-[85vh] overflow-y-auto">
                  <SheetHeader>
                    <SheetTitle>Фильтры</SheetTitle>
                    <SheetDescription>
                      Настройте параметры для поиска автомобиля
                    </SheetDescription>
                  </SheetHeader>
                  <div className="mt-6">
                    <FilterForm />
                    <div className="flex gap-2 mt-6 sticky bottom-0 bg-background pt-4 pb-2">
                      <Button variant="outline" onClick={resetFilters} className="flex-1">
                        Сбросить
                      </Button>
                      <SheetClose asChild>
                        <Button className="flex-1">
                          Применить
                        </Button>
                      </SheetClose>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </div>

            {/* Найдено и активные фильтры */}
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                Найдено: <span className="font-bold text-foreground">{sortedCars.length}</span>
              </p>
              {activeFilters.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  {activeFilters.map((filter, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {filter}
                    </Badge>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* ДЕСКТОП: Результаты и сортировка */}
          <div className="hidden md:flex mb-8 flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <p className="text-muted-foreground font-medium">
              {t('catalogPage.found')} <span className="font-bold">{sortedCars.length}</span>
            </p>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">{t('catalogPage.sorting')}</span>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[220px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="price-asc">{t('catalogPage.sortPriceAsc')}</SelectItem>
                  <SelectItem value="price-desc">{t('catalogPage.sortPriceDesc')}</SelectItem>
                  <SelectItem value="year-desc">{t('catalogPage.sortYearDesc')}</SelectItem>
                  <SelectItem value="mileage-asc">{t('catalogPage.sortMileageAsc')}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Сетка автомобилей */}
          {sortedCars.length === 0 ? (
            <div className="text-center py-20">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-4">
                <svg className="w-8 h-8 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
              <p className="text-xl font-semibold mb-2">
                {t('catalogPage.noResults')}
              </p>
              <p className="text-muted-foreground mb-6">
                {t('catalogPage.tryChange')}
              </p>
              <Button variant="outline" onClick={resetFilters}>
                {t('catalogPage.resetFilters')}
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 lg:gap-8">
              {sortedCars.map((car) => (
                <Card
                  key={car.id}
                  className="group overflow-hidden hover:shadow-2xl md:hover:-translate-y-1 transition-all duration-300"
                >
                  {/* Изображение */}
                  <div className="aspect-[4/3] bg-muted relative overflow-hidden">
                    <Image
                      src={car.imageUrl}
                      alt={`${car.make} ${car.model}`}
                      fill
                      sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                      className="object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    {/* МОБАЙЛ: Компактный бейдж статуса */}
                    <Badge
                      className={`absolute top-2 right-2 md:top-4 md:right-4 ${
                        car.status === 'available'
                          ? 'bg-green-500/90 hover:bg-green-500 text-white border-0'
                          : 'bg-blue-500/90 hover:bg-blue-500 text-white border-0'
                      } px-2 py-0.5 md:px-3 md:py-1 text-[10px] md:text-sm font-medium backdrop-blur-sm`}
                    >
                      {car.status === 'available' ? t('catalogPage.inStock') : t('catalogPage.onOrder')}
                    </Badge>
                  </div>

                  {/* Контент */}
                  <div className="p-3 md:p-4 lg:p-6">
                    {/* МОБАЙЛ: Название и цена - акцент */}
                    <h3 className="text-lg md:text-xl font-bold mb-1 md:mb-2 group-hover:text-primary transition-colors leading-tight">
                      {car.make} {car.model}
                    </h3>

                    {/* МОБАЙЛ: Цена сразу под названием */}
                    <div className="text-xl md:text-2xl font-bold text-primary mb-3 md:mb-4">
                      {t('catalogPage.from')} {car.price.toLocaleString()} ₽
                    </div>

                    {/* МОБАЙЛ: Компактные характеристики */}
                    <div className="space-y-1 md:space-y-2 mb-3 md:mb-5">
                      <div className="flex items-center gap-1.5 md:gap-2 text-xs md:text-sm text-muted-foreground/80">
                        <span className="w-1.5 h-1.5 md:w-2 md:h-2 rounded-full bg-muted-foreground/50"></span>
                        <span>{car.year} {t('catalogPage.year')} • {car.mileage.toLocaleString()} {t('catalogPage.km')}</span>
                      </div>
                      <div className="flex items-center gap-1.5 md:gap-2 text-xs md:text-sm text-muted-foreground/80">
                        <span className="w-1.5 h-1.5 md:w-2 md:h-2 rounded-full bg-muted-foreground/50"></span>
                        <span>{car.fuel} • {car.transmission}</span>
                      </div>
                      <div className="flex items-center gap-1.5 md:gap-2 text-xs md:text-sm text-muted-foreground/80">
                        <span className="w-1.5 h-1.5 md:w-2 md:h-2 rounded-full bg-muted-foreground/50"></span>
                        <span>{car.body}</span>
                      </div>
                    </div>

                    {/* МОБАЙЛ: Второстепенная кнопка / ДЕСКТОП: Основная */}
                    <Button
                      className="w-full md:h-auto"
                      variant="outline"
                      size="sm"
                      asChild
                    >
                      <Link href="/contacts#form" className="md:variant-default">
                        {t('catalogPage.requestButton')}
                      </Link>
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}

          {/* УЛУЧШЕННЫЙ CTA: Не нашли? */}
          <Card className="p-6 md:p-8 mt-8 md:mt-12 text-center bg-gradient-to-br from-primary/10 to-primary/5 md:from-primary/5 md:to-primary/10 border-primary/20">
            <div className="inline-flex items-center justify-center w-12 h-12 md:w-16 md:h-16 rounded-full bg-primary/10 mb-4">
              <svg className="w-6 h-6 md:w-8 md:h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <h2 className="text-xl md:text-2xl lg:text-3xl font-bold mb-3 md:mb-4">{t('catalog.notFound.title')}</h2>
            <p className="text-sm md:text-base lg:text-lg text-muted-foreground mb-5 md:mb-6 max-w-2xl mx-auto leading-relaxed">
              {t('catalog.notFound.desc')}
            </p>
            <Button
              size="lg"
              asChild
              className="w-full md:w-auto shadow-lg hover:shadow-xl bg-gradient-to-r from-primary via-blue-400 via-30% via-blue-500 via-60% to-primary bg-[length:200%_100%] animate-[gradient-wave_3600s_ease-in-out_infinite]"
            >
              <Link href="/contacts#form">{t('catalog.notFound.button')}</Link>
            </Button>
          </Card>
        </div>
      </section>
    </div>
  );
}

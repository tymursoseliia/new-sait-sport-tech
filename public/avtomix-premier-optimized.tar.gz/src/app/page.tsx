'use client';

import { useRef } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CARS } from '@/data/cars';
import {
  CheckCircle2,
  Shield,
  Camera,
  FileText,
  Car,
  Search,
  Truck,
  FileCheck,
  Key,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import ContactForm from '@/components/ContactForm';
import ContactsBlock from '@/components/ContactsBlock';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import FadeInSection from '@/components/FadeInSection';
import { AnimatedCounter } from '@/components/AnimatedCounter';
import { useLanguage } from '@/contexts/LanguageContext';

export default function Home() {
  const { t } = useLanguage();

  // Refs для каруселей
  const servicesScrollRef = useRef<HTMLDivElement>(null);
  const carsScrollRef = useRef<HTMLDivElement>(null);
  const reviewsScrollRef = useRef<HTMLDivElement>(null);

  // Функция для скролла карусели
  const scroll = (ref: React.RefObject<HTMLDivElement>, direction: 'left' | 'right') => {
    if (ref.current) {
      const scrollAmount = direction === 'left' ? -300 : 300;
      ref.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <div className="flex flex-col">
      {/* HERO БЛОК */}
      <section className="relative bg-gradient-to-br from-zinc-900 via-zinc-800 to-zinc-900 dark:from-zinc-950 dark:via-black dark:to-zinc-950 text-white py-10 md:py-32 overflow-hidden">
        {/* ПЕРЕКЛЮЧАТЕЛЬ: Измените USE_VIDEO на true когда загрузите видео */}
        {(() => {
          const USE_VIDEO = false; // ← Измените на true когда загрузите hero-video.mp4

          return USE_VIDEO ? (
            // === ВИДЕО РЕЖИМ ===
            <div className="absolute inset-0 z-0">
              <video
                autoPlay
                loop
                muted
                playsInline
                className="w-full h-full object-cover opacity-30"
              >
                <source src="/videos/hero-video.mp4" type="video/mp4" />
              </video>
              <div className="absolute inset-0 bg-gradient-to-r from-zinc-900/80 to-zinc-900/60" />
            </div>
          ) : (
            // === ИЗОБРАЖЕНИЕ РЕЖИМ (по умолчанию) ===
            <div className="absolute inset-0 z-0">
              <Image
                src="https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=1920"
                alt="Автомобиль"
                fill
                className="object-cover opacity-20"
                priority
              />
              <div className="absolute inset-0 bg-gradient-to-r from-zinc-900/80 to-zinc-900/60" />
            </div>
          );
        })()}
        <div className="container-custom relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-[40px] leading-[1.2] sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4 md:mb-6">
              {t('hero.title')}
            </h1>
            <p className="text-[15px] leading-relaxed sm:text-xl md:text-2xl text-zinc-300 mb-5 md:mb-8 max-w-xl">
              {t('hero.subtitle')}
            </p>
            <div className="flex flex-col gap-3 md:gap-4">
              <Button size="lg" asChild className="w-fit mx-auto md:mx-0 text-base py-6 md:text-lg md:py-7 font-semibold shadow-lg hover:shadow-xl transition-all bg-gradient-to-r from-primary via-blue-400 via-30% via-blue-500 via-60% to-primary bg-[length:200%_100%] animate-[gradient-wave_3600s_ease-in-out_infinite] hover:scale-105 active:scale-95">
                <Link href="/contacts#form">{t('hero.requestButton')}</Link>
              </Button>
              <Link href="/catalog" className="text-center sm:text-left text-[15px] md:text-base text-white/80 hover:text-white underline underline-offset-4 transition-colors md:hidden py-2">
                {t('hero.catalogButton')}
              </Link>
              <Button size="lg" variant="outline" asChild className="hidden md:inline-flex bg-white/10 backdrop-blur border-white/20 text-white hover:bg-white/20">
                <Link href="/catalog">{t('hero.catalogButton')}</Link>
              </Button>
            </div>

            {/* Статистика - поверх изображения на мобиле, показана на десктопе */}
            <div className="grid grid-cols-3 gap-3 md:gap-6 mt-8 md:mt-12">
              <div className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
                  <AnimatedCounter end={6} suffix="+" duration={1500} />
                </div>
                <div className="text-[11px] md:text-sm text-white/90 mt-1 drop-shadow-[0_1px_4px_rgba(0,0,0,0.8)]">{t('hero.years')}</div>
              </div>
              <div className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
                  <AnimatedCounter end={500} suffix="+" duration={2000} />
                </div>
                <div className="text-[11px] md:text-sm text-white/90 mt-1 drop-shadow-[0_1px_4px_rgba(0,0,0,0.8)]">{t('hero.cars')}</div>
              </div>
              <div className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
                  <AnimatedCounter end={98} suffix="%" duration={1800} />
                </div>
                <div className="text-[11px] md:text-sm text-white/90 mt-1 drop-shadow-[0_1px_4px_rgba(0,0,0,0.8)]">{t('hero.clients')}</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* НАШИ УСЛУГИ */}
      <section className="py-6 md:py-16 bg-background">
        <div className="container-custom">
          <FadeInSection>
            <div className="text-center md:text-center mb-6 md:mb-10">
              <h2 className="text-xl md:text-4xl font-bold mb-2 md:mb-3 text-foreground">{t('services.title')}</h2>
              <p className="text-sm md:text-base text-muted-foreground max-w-2xl mx-auto px-2">
                {t('services.subtitle')}
              </p>
            </div>
          </FadeInSection>

          {/* Mobile: horizontal scroll with arrows */}
          <div className="md:hidden relative">
            {/* Стрелки навигации */}
            <button
              onClick={() => scroll(servicesScrollRef, 'left')}
              className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-background/95 backdrop-blur-sm border border-border rounded-full p-2.5 shadow-lg hover:bg-accent active:scale-95 transition-all touch-manipulation"
              aria-label="Предыдущая услуга"
            >
              <ChevronLeft className="w-5 h-5 text-foreground" />
            </button>
            <button
              onClick={() => scroll(servicesScrollRef, 'right')}
              className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-background/95 backdrop-blur-sm border border-border rounded-full p-2.5 shadow-lg hover:bg-accent active:scale-95 transition-all touch-manipulation"
              aria-label="Следующая услуга"
            >
              <ChevronRight className="w-5 h-5 text-foreground" />
            </button>

            <div ref={servicesScrollRef} className="-mx-4 px-4 overflow-x-auto snap-x snap-mandatory scrollbar-hide">
              <div className="flex gap-3 pb-4">
            {[
              {
                icon: Search,
                title: t('services.selection.title'),
                description: t('services.selection.desc'),
              },
              {
                icon: Shield,
                title: t('services.inspection.title'),
                description: t('services.inspection.desc'),
              },
              {
                icon: Truck,
                title: t('services.delivery.title'),
                description: t('services.delivery.desc'),
              },
              {
                icon: FileCheck,
                title: t('services.registration.title'),
                description: t('services.registration.desc'),
              },
            ].map((service, index) => (
              <Card key={index} className="flex-shrink-0 w-[280px] snap-start bg-card border rounded-xl p-5 shadow-sm active:shadow-md transition-shadow">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary mb-3">
                  <service.icon className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold mb-2 text-foreground leading-tight">
                  {service.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {service.description}
                </p>
              </Card>
            ))}
              </div>
            </div>
          </div>

          {/* Desktop: grid */}
          <div className="hidden md:grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {[
              {
                icon: Search,
                title: t('services.selection.title'),
                description: t('services.selection.desc'),
              },
              {
                icon: Shield,
                title: t('services.inspection.title'),
                description: t('services.inspection.desc'),
              },
              {
                icon: Truck,
                title: t('services.delivery.title'),
                description: t('services.delivery.desc'),
              },
              {
                icon: FileCheck,
                title: t('services.registration.title'),
                description: t('services.registration.desc'),
              },
            ].map((service, index) => (
              <FadeInSection key={index} delay={index * 0.1}>
                <Card className="group relative h-full bg-card border rounded-xl p-6 hover:shadow-lg hover:-translate-y-1 transition-all duration-300">
                  <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-primary/10 text-primary group-hover:bg-primary group-hover:text-white transition-all duration-300 mb-4">
                    <service.icon className="w-7 h-7" />
                  </div>
                  <h3 className="text-lg font-bold mb-2 text-foreground">
                    {service.title}
                  </h3>
                  <p className="text-sm text-zinc-600 leading-relaxed">
                    {service.description}
                  </p>
                </Card>
              </FadeInSection>
            ))}
          </div>

          <div className="text-center mt-6 md:mt-8">
            <Button size="lg" variant="outline" asChild className="text-base font-medium min-w-[200px]">
              <Link href="/services">
                {t('services.viewAll')}
                <span className="ml-2 transition-transform group-hover:translate-x-1">→</span>
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* ПОЧЕМУ НАС ВЫБИРАЮТ */}
      <section className="py-6 md:py-16 bg-muted/30">
        <div className="container-custom">
          <FadeInSection>
            <div className="text-center mb-6 md:mb-8">
              <h2 className="text-xl md:text-4xl font-bold mb-2 md:mb-3">{t('whyUs.title')}</h2>
              <p className="text-sm md:text-base text-muted-foreground max-w-2xl mx-auto px-2">
                {t('whyUs.subtitle')}
              </p>
            </div>
          </FadeInSection>

          <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6">
            {[
              {
                icon: Shield,
                title: t('whyUs.platforms.title'),
                description: t('whyUs.platforms.desc'),
              },
              {
                icon: FileText,
                title: t('whyUs.contract.title'),
                description: t('whyUs.contract.desc'),
              },
              {
                icon: Camera,
                title: t('whyUs.reports.title'),
                description: t('whyUs.reports.desc'),
              },
              {
                icon: CheckCircle2,
                title: t('whyUs.legal.title'),
                description: t('whyUs.legal.desc'),
              },
            ].map((advantage, index) => (
              <Card key={index} className="flex flex-col items-center text-center p-4 md:p-0 md:bg-transparent md:border-0 md:shadow-none">
                <div className="h-10 w-10 md:h-12 md:w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-2 md:mb-3">
                  <advantage.icon className="h-5 w-5 md:h-6 md:w-6 text-primary" />
                </div>
                <h3 className="text-sm md:text-base font-bold mb-1 leading-tight">{advantage.title}</h3>
                <p className="text-xs md:text-sm text-muted-foreground leading-snug">{advantage.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* ПРОЦЕСС РАБОТЫ */}
      <section className="hidden md:block py-6 md:py-16 bg-background">
        <div className="container-custom">
          <FadeInSection>
            <div className="text-center mb-8">
              <h2 className="text-3xl md:text-4xl font-bold mb-3">{t('howWeWork.title')}</h2>
              <p className="text-base text-muted-foreground max-w-2xl mx-auto">
                {t('howWeWork.subtitle')}
              </p>
            </div>
          </FadeInSection>

          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                {
                  step: '01',
                  title: t('howWeWork.step1.title'),
                  description: t('howWeWork.step1.desc'),
                },
                {
                  step: '02',
                  title: t('howWeWork.step2.title'),
                  description: t('howWeWork.step2.desc'),
                },
                {
                  step: '03',
                  title: t('howWeWork.step3.title'),
                  description: t('howWeWork.step3.desc'),
                },
              ].map((item, index) => (
                <Card key={index} className="p-6 text-center">
                  <div className="h-14 w-14 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xl font-bold mx-auto mb-4">
                    {item.step}
                  </div>
                  <h3 className="text-lg font-bold mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{item.description}</p>
                </Card>
              ))}
            </div>
          </div>

          <div className="text-center mt-8">
            <Button size="lg" variant="outline" asChild className="text-base font-medium min-w-[200px]">
              <Link href="/how-we-work">
                {t('howWeWork.moreButton')}
                <span className="ml-2 transition-transform group-hover:translate-x-1">→</span>
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* ПОПУЛЯРНЫЕ ПРЕДЛОЖЕНИЯ */}
      <section className="py-6 md:py-16 bg-muted/30">
        <div className="container-custom">
          <FadeInSection>
            <div className="text-center mb-8">
              <h2 className="text-3xl md:text-4xl font-bold mb-3">{t('catalog.title')}</h2>
              <p className="text-base text-muted-foreground max-w-2xl mx-auto">
                {t('catalog.subtitle')}
              </p>
            </div>
          </FadeInSection>

          {/* Mobile: carousel with arrows */}
          <div className="md:hidden relative">
            <button
              onClick={() => scroll(carsScrollRef, 'left')}
              className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-background/95 backdrop-blur-sm border border-border rounded-full p-2.5 shadow-lg hover:bg-accent active:scale-95 transition-all touch-manipulation"
              aria-label="Предыдущее авто"
            >
              <ChevronLeft className="w-5 h-5 text-foreground" />
            </button>
            <button
              onClick={() => scroll(carsScrollRef, 'right')}
              className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-background/95 backdrop-blur-sm border border-border rounded-full p-2.5 shadow-lg hover:bg-accent active:scale-95 transition-all touch-manipulation"
              aria-label="Следующее авто"
            >
              <ChevronRight className="w-5 h-5 text-foreground" />
            </button>

            <div ref={carsScrollRef} className="-mx-4 px-4 overflow-x-auto snap-x snap-mandatory scrollbar-hide">
              <div className="flex gap-4 pb-4">
                {CARS.slice(0, 6).map((car) => (
                  <Card key={car.id} className="flex-shrink-0 w-[300px] snap-start overflow-hidden shadow-sm active:shadow-md transition-all">
                    <div className="aspect-video bg-muted relative">
                      <Image
                        src={car.imageUrl}
                        alt={`${car.make} ${car.model}`}
                        fill
                        sizes="300px"
                        className="object-cover"
                      />
                      <Badge className="absolute top-3 right-3 shadow-sm">
                        {car.status === 'available' ? t('catalog.available') : t('catalog.order')}
                      </Badge>
                    </div>
                    <div className="p-5">
                      <h3 className="text-lg font-bold mb-2 leading-tight">
                        {car.make} {car.model}
                      </h3>
                      <div className="flex gap-2.5 text-sm text-muted-foreground mb-3">
                        <span>{car.year}</span>
                        <span>•</span>
                        <span>{car.mileage.toLocaleString('ru-RU')} км</span>
                      </div>
                      <div className="text-xl font-bold text-primary mb-4">
                        {t('catalog.from')} {car.price.toLocaleString('ru-RU')} ₽
                      </div>
                      <Button className="w-full shadow-sm" size="default">{t('catalog.requestButton')}</Button>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </div>

          {/* Desktop: grid */}
          <div className="hidden md:grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {CARS.slice(0, 3).map((car) => (
              <Card key={car.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-video bg-muted relative">
                  <Image
                    src={car.imageUrl}
                    alt={`${car.make} ${car.model}`}
                    fill
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                    className="object-cover"
                  />
                  <Badge className="absolute top-4 right-4">
                    {car.status === 'available' ? t('catalog.available') : t('catalog.order')}
                  </Badge>
                </div>
                <div className="p-6">
                  <h3 className="text-2xl font-bold mb-2">
                    {car.make} {car.model}
                  </h3>
                  <div className="flex gap-4 text-sm text-muted-foreground mb-4">
                    <span>{car.year}</span>
                    <span>•</span>
                    <span>{car.mileage.toLocaleString('ru-RU')} км</span>
                  </div>
                  <div className="text-2xl font-bold text-primary mb-4">
                    {t('catalog.from')} {car.price.toLocaleString('ru-RU')} ₽
                  </div>
                  <Button className="w-full">{t('catalog.requestButton')}</Button>
                </div>
              </Card>
            ))}
          </div>

          <div className="text-center mt-8">
            <Button size="lg" variant="outline" asChild className="text-base font-medium min-w-[200px]">
              <Link href="/catalog">
                {t('catalog.viewAll')}
                <span className="ml-2 transition-transform group-hover:translate-x-1">→</span>
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* ОТЗЫВЫ */}
      <section className="py-6 md:py-16 bg-background">
        <div className="container-custom">
          <FadeInSection>
            <div className="text-center mb-8">
              <h2 className="text-3xl md:text-4xl font-bold mb-3">{t('reviews.title')}</h2>
              <p className="text-base text-muted-foreground max-w-2xl mx-auto">
                {t('reviews.subtitle')}
              </p>
            </div>
          </FadeInSection>

          {/* Mobile: carousel with arrows */}
          <div className="md:hidden relative">
            <button
              onClick={() => scroll(reviewsScrollRef, 'left')}
              className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-background/95 backdrop-blur-sm border border-border rounded-full p-2.5 shadow-lg hover:bg-accent active:scale-95 transition-all touch-manipulation"
              aria-label="Предыдущий отзыв"
            >
              <ChevronLeft className="w-5 h-5 text-foreground" />
            </button>
            <button
              onClick={() => scroll(reviewsScrollRef, 'right')}
              className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-background/95 backdrop-blur-sm border border-border rounded-full p-2.5 shadow-lg hover:bg-accent active:scale-95 transition-all touch-manipulation"
              aria-label="Следующий отзыв"
            >
              <ChevronRight className="w-5 h-5 text-foreground" />
            </button>

            <div ref={reviewsScrollRef} className="-mx-4 px-4 overflow-x-auto snap-x snap-mandatory scrollbar-hide">
              <div className="flex gap-4 pb-4">
                {[
                  {
                    name: 'Алексей М.',
                    city: 'Москва',
                    car: 'Toyota Prius',
                    country: 'Германия',
                    text: 'Помогли подобрать идеальный вариант из Германии. Автомобиль в отличном состоянии, все документы в порядке.',
                    rating: 5,
                  },
                  {
                    name: 'Дмитрий К.',
                    city: 'Санкт-Петербург',
                    car: 'Toyota RAV4',
                    country: 'Франция',
                    text: 'Профессиональный подход на всех этапах. Сэкономил около 500 тысяч рублей по сравнению с покупкой в России.',
                    rating: 5,
                  },
                  {
                    name: 'Игорь С.',
                    city: 'Краснодар',
                    car: 'Hyundai Santa Fe',
                    country: 'Германия',
                    text: 'Это уже второй автомобиль через AVTOMIX PREMIER. Ребята знают свое дело, все четко и в срок.',
                    rating: 5,
                  },
                  {
                    name: 'Марина В.',
                    city: 'Казань',
                    car: 'BMW X5',
                    country: 'Германия',
                    text: 'Отличный сервис! Помогли с выбором, организовали доставку, все прошло быстро и без проблем.',
                    rating: 5,
                  },
                  {
                    name: 'Сергей П.',
                    city: 'Екатеринбург',
                    car: 'Audi A6',
                    country: 'Германия',
                    text: 'Профессионалы своего дела. Машина в идеальном состоянии, цена выгоднее чем в России.',
                    rating: 5,
                  },
                ].map((review, index) => (
                  <Card key={index} className="flex-shrink-0 w-[300px] snap-start p-5 shadow-sm active:shadow-md transition-shadow">
                    <div className="flex gap-0.5 mb-3">
                      {[...Array(review.rating)].map((_, i) => (
                        <span key={i} className="text-yellow-500 text-base">
                          ★
                        </span>
                      ))}
                    </div>
                    <p className="text-sm text-muted-foreground mb-4 leading-relaxed min-h-[80px]">{review.text}</p>
                    <div className="border-t pt-3 mt-auto">
                      <div className="font-semibold text-sm text-foreground">{review.name}</div>
                      <div className="text-xs text-muted-foreground mt-0.5">
                        {review.city} • {review.car}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </div>

          {/* Desktop: grid */}
          <div className="hidden md:grid grid-cols-1 md:grid-cols-3 gap-5">
            {[
              {
                name: 'Алексей М.',
                city: 'Москва',
                car: 'Toyota Prius',
                country: 'Германия',
                text: 'Помогли подобрать идеальный вариант из Германии. Автомобиль в отличном состоянии, все документы в порядке.',
                rating: 5,
              },
              {
                name: 'Дмитрий К.',
                city: 'Санкт-Петербург',
                car: 'Toyota RAV4',
                country: 'Франция',
                text: 'Профессиональный подход на всех этапах. Сэкономил около 500 тысяч рублей по сравнению с покупкой в России.',
                rating: 5,
              },
              {
                name: 'Игорь С.',
                city: 'Краснодар',
                car: 'Hyundai Santa Fe',
                country: 'Германия',
                text: 'Это уже второй автомобиль через AVTOMIX PREMIER. Ребята знают свое дело, все четко и в срок.',
                rating: 5,
              },
            ].map((review, index) => (
              <Card key={index} className="p-5">
                <div className="flex gap-1 mb-3">
                  {[...Array(review.rating)].map((_, i) => (
                    <span key={i} className="text-yellow-500 text-lg">
                      ★
                    </span>
                  ))}
                </div>
                <p className="text-sm text-muted-foreground mb-4 leading-relaxed">{review.text}</p>
                <div className="border-t pt-3">
                  <div className="font-bold text-sm">{review.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {review.city} • {review.car}
                  </div>
                </div>
              </Card>
            ))}
          </div>

          <div className="text-center mt-8">
            <Button size="lg" variant="outline" asChild className="text-base font-medium min-w-[200px]">
              <Link href="/reviews">
                {t('reviews.viewAll')}
                <span className="ml-2 transition-transform group-hover:translate-x-1">→</span>
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="hidden md:block py-6 md:py-16 bg-muted/30">
        <div className="container-custom">
          <FadeInSection>
            <div className="text-center mb-8">
              <h2 className="text-3xl md:text-4xl font-bold mb-3">{t('faq.title')}</h2>
              <p className="text-base text-muted-foreground max-w-2xl mx-auto">
                {t('faq.subtitle')}
              </p>
            </div>
          </FadeInSection>

          <div className="max-w-3xl mx-auto">
            <Accordion type="single" collapsible>
              <AccordionItem value="item-1">
                <AccordionTrigger>{t('faq.q1')}</AccordionTrigger>
                <AccordionContent>
                  {t('faq.a1')}
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-2">
                <AccordionTrigger>{t('faq.q2')}</AccordionTrigger>
                <AccordionContent>
                  {t('faq.a2')}
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-3">
                <AccordionTrigger>{t('faq.q3')}</AccordionTrigger>
                <AccordionContent>
                  {t('faq.a3')}
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-4">
                <AccordionTrigger>{t('faq.q4')}</AccordionTrigger>
                <AccordionContent>
                  {t('faq.a4')}
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>

          <div className="text-center mt-8">
            <Button size="lg" variant="outline" asChild className="text-base font-medium min-w-[200px]">
              <Link href="/faq">
                {t('faq.viewAll')}
                <span className="ml-2 transition-transform group-hover:translate-x-1">→</span>
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* ФОРМА ЗАЯВКИ */}
      <section id="form" className="py-6 md:py-16 bg-background">
        <div className="container-custom">
          <div className="max-w-2xl mx-auto">
            <ContactForm
              title={t('contact.title')}
              subtitle={t('contact.subtitle')}
              showCarLink={false}
            />
          </div>
        </div>
      </section>
    </div>
  );
}

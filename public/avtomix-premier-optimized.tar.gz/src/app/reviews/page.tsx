'use client';

import { useState, useMemo } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { REVIEWS, getAverageRating, getUniqueCities, getUniqueBrands } from '@/data/reviews';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Star, TrendingDown, Clock, Users, BadgeCheck, Shield, SlidersHorizontal } from 'lucide-react';
import Breadcrumbs from '@/components/Breadcrumbs';
import ReviewForm from '@/components/ReviewForm';
import { useLanguage } from '@/contexts/LanguageContext';

export default function ReviewsPage() {
  const { t } = useLanguage();
  const [filterBrand, setFilterBrand] = useState('all');
  const [filterCity, setFilterCity] = useState('all');
  const [sortBy, setSortBy] = useState('newest');
  const [expandedReviews, setExpandedReviews] = useState<number[]>([]);
  const [showFilters, setShowFilters] = useState(false);

  // Используем функции из @/data/reviews
  const averageRating = getAverageRating();
  const cities = getUniqueCities();
  const brands = getUniqueBrands();

  // Фильтрация и сортировка
  const filteredAndSortedReviews = useMemo(() => {
    let filtered = REVIEWS;

    if (filterBrand !== 'all') {
      filtered = filtered.filter((review) => review.brand === filterBrand);
    }

    if (filterCity !== 'all') {
      filtered = filtered.filter((review) => review.city === filterCity);
    }

    const sorted = [...filtered];
    if (sortBy === 'newest') {
      sorted.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    } else if (sortBy === 'oldest') {
      sorted.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    }

    return sorted;
  }, [filterBrand, filterCity, sortBy]);

  const toggleExpand = (reviewId: number) => {
    setExpandedReviews((prev) =>
      prev.includes(reviewId) ? prev.filter((id) => id !== reviewId) : [...prev, reviewId]
    );
  };

  const isExpanded = (reviewId: number) => expandedReviews.includes(reviewId);

  // Функция обрезки текста по предложениям
  const truncateText = (text: string, maxLength: number = 280) => {
    if (text.length <= maxLength) return text;

    const truncated = text.slice(0, maxLength);
    const lastSentenceEnd = Math.max(
      truncated.lastIndexOf('.'),
      truncated.lastIndexOf('!'),
      truncated.lastIndexOf('?')
    );

    if (lastSentenceEnd > 0) {
      return text.slice(0, lastSentenceEnd + 1);
    }

    return truncated + '...';
  };

  const needsTruncate = (text: string) => text.length > 280;

  // Отрисовка звёзд рейтинга
  const renderStars = (rating: number) => {
    return (
      <div className="flex gap-0.5 mb-3 md:mb-3">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-4 h-4 ${
              star <= Math.floor(rating)
                ? 'fill-yellow-500 text-yellow-500'
                : star === Math.ceil(rating) && rating % 1 !== 0
                ? 'fill-yellow-500 text-yellow-500 opacity-50'
                : 'text-zinc-300'
            }`}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="flex flex-col">
      <Breadcrumbs items={[{ label: t('nav.reviews') }]} />

      {/* Hero секция с статистикой */}
      <section className="bg-gradient-to-br from-muted/50 to-muted py-5 md:py-24">
        <div className="container-custom px-4">
          <div className="grid lg:grid-cols-[1fr_auto] gap-4 md:gap-8 items-start">
            {/* Заголовок */}
            <div>
              <h1 className="text-xl leading-tight md:text-5xl font-bold mb-2 md:mb-4">
                {t('reviewsPage.title')}
              </h1>
              <p className="text-sm leading-snug md:text-xl md:leading-relaxed text-muted-foreground">
                {t('reviewsPage.subtitle')}
              </p>
            </div>

            {/* Обновленная статистика */}
            <Card className="p-4 md:p-8 shadow-lg min-w-[280px]">
              <div className="text-center">
                {/* Крупная цифра рейтинга */}
                <div className="flex items-center justify-center gap-2 mb-2 md:mb-3">
                  <span className="text-3xl md:text-5xl font-bold">{averageRating}</span>
                  <span className="text-lg md:text-2xl text-muted-foreground font-medium">{t('reviewsPage.rating.outOf')}</span>
                </div>

                {/* Звёзды */}
                <div className="flex justify-center gap-0.5 md:gap-1 mb-2 md:mb-4">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`w-4 md:w-6 h-4 md:h-6 ${
                        star <= Math.floor(averageRating)
                          ? 'fill-yellow-500 text-yellow-500'
                          : star === Math.ceil(averageRating) && averageRating % 1 !== 0
                          ? 'fill-yellow-500 text-yellow-500 opacity-50'
                          : 'fill-zinc-300 text-zinc-300'
                      }`}
                    />
                  ))}
                </div>

                {/* Количество отзывов - компактная версия на мобильных */}
                <p className="text-xs md:text-sm text-muted-foreground mb-2 md:mb-4">
                  {REVIEWS.length} {t('reviewsPage.rating.reviews')}
                </p>

                {/* Проверено бейдж - компактнее на мобильных */}
                <div className="flex items-center justify-center gap-1.5 md:gap-2 p-1.5 md:p-2 bg-green-500/20 dark:bg-green-500/30 rounded-lg">
                  <BadgeCheck className="w-3.5 md:w-5 h-3.5 md:h-5 text-green-600 dark:text-green-400" />
                  <span className="text-xs md:text-sm font-semibold text-green-600 dark:text-green-300">{t('reviewsPage.rating.verified')}</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Фильтры и отзывы */}
      <section className="py-6 md:py-24">
        <div className="container-custom px-4">
          {/* Улучшенные фильтры */}

          {/* МОБИЛЬНАЯ ВЕРСИЯ: Компактная панель */}
          <div className="lg:hidden mb-6">
            <div className="flex items-center justify-between mb-3">
              <p className="text-sm text-muted-foreground">
                {t('reviewsPage.filters.found')} <span className="font-bold">{filteredAndSortedReviews.length}</span>
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowFilters(!showFilters)}
                className="gap-2"
              >
                <SlidersHorizontal className="w-4 h-4" />
                Фильтры
              </Button>
            </div>

            {/* Раскрывающаяся панель фильтров */}
            {showFilters && (
              <Card className="p-4 shadow-sm">
                <div className="space-y-3">
                  {/* Фильтр по марке */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-muted-foreground">{t('reviewsPage.filters.brand')}</label>
                    <Select value={filterBrand} onValueChange={setFilterBrand}>
                      <SelectTrigger className="h-9">
                        <SelectValue placeholder={t('reviewsPage.filters.allBrands')} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">{t('reviewsPage.filters.allBrands')}</SelectItem>
                        {brands.map((brand) => (
                          <SelectItem key={brand} value={brand}>
                            {brand}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Фильтр по городу */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-muted-foreground">{t('reviewsPage.filters.city')}</label>
                    <Select value={filterCity} onValueChange={setFilterCity}>
                      <SelectTrigger className="h-9">
                        <SelectValue placeholder={t('reviewsPage.filters.allCities')} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">{t('reviewsPage.filters.allCities')}</SelectItem>
                        {cities.map((city) => (
                          <SelectItem key={city} value={city}>
                            {city}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Сортировка */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-muted-foreground">{t('reviewsPage.filters.sort')}</label>
                    <Select value={sortBy} onValueChange={setSortBy}>
                      <SelectTrigger className="h-9">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="newest">{t('reviewsPage.filters.newest')}</SelectItem>
                        <SelectItem value="oldest">{t('reviewsPage.filters.oldest')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <Button
                      size="sm"
                      className="flex-1"
                      onClick={() => setShowFilters(false)}
                    >
                      Применить
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setFilterBrand('all');
                        setFilterCity('all');
                        setSortBy('newest');
                      }}
                    >
                      Сбросить
                    </Button>
                  </div>
                </div>
              </Card>
            )}
          </div>

          {/* ДЕСКТОПНАЯ ВЕРСИЯ: Оригинальные фильтры */}
          <Card className="hidden lg:block p-4 md:p-6 mb-10 shadow-sm">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
              {/* Фильтр по марке */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">{t('reviewsPage.filters.brand')}</label>
                <Select value={filterBrand} onValueChange={setFilterBrand}>
                  <SelectTrigger>
                    <SelectValue placeholder={t('reviewsPage.filters.allBrands')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t('reviewsPage.filters.allBrands')}</SelectItem>
                    {brands.map((brand) => (
                      <SelectItem key={brand} value={brand}>
                        {brand}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Фильтр по городу */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">{t('reviewsPage.filters.city')}</label>
                <Select value={filterCity} onValueChange={setFilterCity}>
                  <SelectTrigger>
                    <SelectValue placeholder={t('reviewsPage.filters.allCities')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t('reviewsPage.filters.allCities')}</SelectItem>
                    {cities.map((city) => (
                      <SelectItem key={city} value={city}>
                        {city}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Сортировка */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">{t('reviewsPage.filters.sort')}</label>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">{t('reviewsPage.filters.newest')}</SelectItem>
                    <SelectItem value="oldest">{t('reviewsPage.filters.oldest')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Счетчик результатов */}
            <div className="mt-4 pt-4 border-t">
              <p className="text-sm text-muted-foreground">
                {t('reviewsPage.filters.found')} <span className="font-bold">{filteredAndSortedReviews.length}</span>
              </p>
            </div>
          </Card>

          {/* Сетка отзывов */}
          <div className="grid md:grid-cols-2 gap-4 md:gap-6 lg:gap-8">
            {filteredAndSortedReviews.map((review) => {
              const textToShow = needsTruncate(review.text)
                ? isExpanded(review.id)
                  ? review.text
                  : truncateText(review.text)
                : review.text;

              return (
                <Card
                  key={review.id}
                  className="overflow-hidden hover:shadow-xl transition-shadow flex flex-col"
                >
                  {/* Фото автомобиля - компактнее на мобильных */}
                  {review.imageUrl && (
                    <div className="aspect-[16/9] md:aspect-[16/10] bg-muted overflow-hidden">
                      <img
                        src={review.imageUrl}
                        alt={review.car}
                        loading="lazy"
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                  )}

                  {/* Контент карточки - компактнее на мобильных */}
                  <div className="p-3 md:p-6 md:p-7 flex flex-col flex-1">
                    {/* Заголовок: марка и модель */}
                    <h3 className="text-base md:text-lg font-bold mb-1">{review.car}</h3>

                    {/* Маршрут */}
                    <p className="text-xs md:text-sm text-muted-foreground mb-2 md:mb-4">
                      {review.country} → {review.city}
                    </p>

                    {/* Звёзды рейтинга - выше, ближе к заголовку */}
                    {review.rating && (
                      <div className="flex gap-0.5 mb-2 md:mb-3">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`w-3.5 md:w-4 h-3.5 md:h-4 ${
                              star <= Math.floor(review.rating!)
                                ? 'fill-yellow-500 text-yellow-500'
                                : star === Math.ceil(review.rating!) && review.rating! % 1 !== 0
                                ? 'fill-yellow-500 text-yellow-500 opacity-50'
                                : 'text-zinc-300'
                            }`}
                          />
                        ))}
                      </div>
                    )}

                    {/* Бейджи с выгодами - компактнее */}
                    {review.highlights && (
                      <div className="flex flex-wrap gap-1.5 md:gap-2 mb-3 md:mb-4">
                        {review.highlights.savings && (
                          <Badge
                            className="bg-green-500/90 hover:bg-green-500 text-white border-0 text-[10px] md:text-xs px-2 md:px-2.5 py-0.5 md:py-1 font-medium backdrop-blur-sm"
                          >
                            <TrendingDown className="w-3 md:w-3.5 h-3 md:h-3.5 mr-0.5 md:mr-1" />
                            {review.highlights.savings}
                          </Badge>
                        )}
                        {review.highlights.time && (
                          <Badge
                            className="bg-blue-500/90 hover:bg-blue-500 text-white border-0 text-[10px] md:text-xs px-2 md:px-2.5 py-0.5 md:py-1 font-medium backdrop-blur-sm"
                          >
                            <Clock className="w-3 md:w-3.5 h-3 md:h-3.5 mr-0.5 md:mr-1" />
                            {review.highlights.time}
                          </Badge>
                        )}
                        {review.highlights.repeat && (
                          <Badge
                            className="bg-purple-500/90 hover:bg-purple-500 text-white border-0 text-[10px] md:text-xs px-2 md:px-2.5 py-0.5 md:py-1 font-medium backdrop-blur-sm"
                          >
                            <Users className="w-3 md:w-3.5 h-3 md:h-3.5 mr-0.5 md:mr-1" />
                            {t('reviewsPage.highlights.repeat')}
                          </Badge>
                        )}
                      </div>
                    )}

                    {/* Текст отзыва - компактнее */}
                    <p className="text-sm md:text-base text-muted-foreground leading-snug md:leading-relaxed mb-3 md:mb-4 flex-1">
                      {textToShow}
                    </p>

                    {/* Кнопка "Показать полностью" */}
                    {needsTruncate(review.text) && (
                      <button
                        onClick={() => toggleExpand(review.id)}
                        className="text-xs md:text-sm text-primary hover:text-primary/80 font-medium mb-3 md:mb-4 text-left transition-colors"
                      >
                        {isExpanded(review.id) ? t('reviewsPage.showLess') : t('reviewsPage.showMore')}
                      </button>
                    )}

                    {/* Автор отзыва - компактная версия */}
                    <div className="border-t pt-3 md:pt-4">
                      <div className="flex items-start justify-between gap-2 mb-2 md:mb-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 md:gap-2 mb-0.5">
                            <p className="font-semibold text-sm md:text-base truncate">{review.name}</p>
                            {review.verified && (
                              <span title={t('reviewsPage.verifiedClient')} className="flex-shrink-0">
                                <BadgeCheck className="w-3.5 md:w-5 h-3.5 md:h-5 text-blue-400 fill-blue-400" />
                              </span>
                            )}
                          </div>
                          <p className="text-xs md:text-sm text-muted-foreground">{review.city}</p>
                        </div>
                        <p className="text-[10px] md:text-xs text-muted-foreground whitespace-nowrap">
                          {new Date(review.date).toLocaleDateString('ru-RU', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric',
                          })}
                        </p>
                      </div>

                      {/* Бейджи статуса - компактнее */}
                      <div className="flex flex-wrap gap-1.5">
                        {review.purchaseVerified && (
                          <Badge
                            className="bg-green-500/90 hover:bg-green-500 text-white border-0 text-[10px] md:text-xs px-2 md:px-2.5 py-0.5 md:py-1 font-medium backdrop-blur-sm"
                          >
                            <BadgeCheck className="w-2.5 md:w-3 h-2.5 md:h-3 mr-0.5 md:mr-1" />
                            {t('reviewsPage.verifiedPurchase')}
                          </Badge>
                        )}
                        {review.highlights?.repeat && (
                          <Badge
                            className="bg-purple-500/90 hover:bg-purple-500 text-white border-0 text-[10px] md:text-xs px-2 md:px-2.5 py-0.5 md:py-1 font-medium backdrop-blur-sm"
                          >
                            Повторный клиент
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>

          {/* Нижний блок CTA - объединенный на мобильных */}

          {/* МОБИЛЬНАЯ ВЕРСИЯ: Один объединенный блок */}
          <div className="lg:hidden mt-8">
            <Card className="p-4 bg-gradient-to-br from-primary/5 to-primary/10 dark:from-primary/10 dark:to-primary/20 border-primary/30 text-center">
              <div className="flex items-center justify-center gap-2 mb-3">
                <Badge className="bg-blue-500/90 hover:bg-blue-500 text-white border-0 text-[10px] px-2 py-1 font-medium backdrop-blur-sm gap-1">
                  <Clock className="w-3 h-3" />
                  6+ лет опыта
                </Badge>
                <Badge className="bg-blue-500/90 hover:bg-blue-500 text-white border-0 text-[10px] px-2 py-1 font-medium backdrop-blur-sm gap-1">
                  <Users className="w-3 h-3" />
                  500+ клиентов
                </Badge>
              </div>

              <h2 className="text-lg font-bold mb-2 leading-tight">
                Поделитесь опытом или начните свой
              </h2>
              <p className="text-sm text-muted-foreground mb-4 leading-snug">
                Уже купили автомобиль? Расскажите другим. Хотите такой же сервис? Начните прямо сейчас.
              </p>

              <div className="space-y-2">
                <Button size="default" asChild className="w-full h-10">
                  <Link href="/reviews#review-form">Оставить отзыв</Link>
                </Button>
                <Button size="default" variant="outline" asChild className="w-full h-10">
                  <Link href="/contacts#form">Начать подбор</Link>
                </Button>
              </div>
            </Card>
          </div>

          {/* ДЕСКТОПНАЯ ВЕРСИЯ: Два раздельных блока */}
          <div className="hidden lg:grid md:grid-cols-2 gap-6 mt-16">
            {/* Оставить отзыв */}
            <Card className="p-5 md:p-8 bg-gradient-to-br from-primary/5 to-primary/10 dark:from-primary/10 dark:to-primary/20 border-primary/30 text-center md:text-left">
              <h2 className="text-2xl md:text-3xl font-bold mb-3">
                {t('reviewsPage.cta.bought.title')}
              </h2>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                {t('reviewsPage.cta.bought.desc')}
              </p>
              <Button size="lg" asChild className="w-full md:w-auto">
                <Link href="/reviews#review-form">{t('reviewsPage.cta.bought.button')}</Link>
              </Button>
            </Card>

            {/* Начать подбор */}
            <Card className="p-5 md:p-8 bg-gradient-to-br from-blue-500/5 to-blue-500/10 dark:from-blue-500/10 dark:to-blue-500/20 border-blue-500/30 text-center md:text-left">
              <h2 className="text-2xl md:text-3xl font-bold mb-3">
                {t('reviewsPage.cta.want.title')}
              </h2>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                {t('reviewsPage.cta.want.desc')}
              </p>
              <Button size="lg" asChild className="w-full md:w-auto">
                <Link href="/contacts#form">{t('reviewsPage.cta.want.button')}</Link>
              </Button>
            </Card>
          </div>
        </div>
      </section>

      {/* Форма для отзыва - только на десктопе */}
      <section id="review-form" className="hidden lg:block py-6 md:py-24 bg-muted/30 scroll-mt-20">
        <div className="container-custom px-4">
          <div className="max-w-3xl mx-auto">
            <ReviewForm />
          </div>
        </div>
      </section>
    </div>
  );
}

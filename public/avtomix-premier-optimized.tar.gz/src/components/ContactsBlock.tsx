'use client';

import Link from 'next/link';
import { Phone, Mail, MessageCircle, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { CONTACTS } from '@/config/contacts';
import { useLanguage } from '@/contexts/LanguageContext';

export default function ContactsBlock() {
  const { t } = useLanguage();

  return (
    <section className="py-8 md:py-24 bg-gradient-to-br from-muted/50 to-muted">
      <div className="container-custom px-4">
        <div className="max-w-6xl mx-auto">
          {/* Заголовок */}
          <div className="text-center mb-6 md:mb-12">
            <h2 className="text-2xl leading-tight md:text-4xl font-bold mb-2 md:mb-4">{t('contactsBlock.title')}</h2>
            <p className="text-base md:text-lg text-muted-foreground leading-snug">
              {t('contactsBlock.subtitle')}
            </p>
          </div>

          {/* Основной блок контактов */}
          <div className="grid md:grid-cols-2 gap-4 md:gap-8 mb-8 md:mb-12">
            {/* Блок с телефоном - главный CTA на мобильных */}
            <div className="md:space-y-6">
              {/* Телефон - главный канал */}
              <Card className="p-5 md:p-8 border-2 border-primary shadow-lg">
                <div className="text-center md:text-left md:flex md:items-start md:gap-4">
                  <div className="flex-shrink-0 hidden md:block">
                    <div className="w-14 h-14 rounded-full bg-primary/10 dark:bg-primary/20 flex items-center justify-center">
                      <Phone className="w-7 h-7 text-primary" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <p className="text-xs md:text-sm font-medium text-muted-foreground mb-2">{t('contactsBlock.callUs')}</p>
                    <a
                      href={CONTACTS.phoneHref}
                      className="text-xl md:text-3xl font-bold hover:text-primary transition-colors block mb-3 md:mb-4"
                    >
                      {CONTACTS.phone}
                    </a>
                    <Button asChild className="w-full md:w-auto">
                      <a href={CONTACTS.phoneHref}>
                        <Phone className="w-4 h-4 mr-2" />
                        {t('contactsBlock.orderCall')}
                      </a>
                    </Button>
                  </div>
                </div>
              </Card>

            </div>

            {/* Блок "Написать нам" - email и мессенджеры */}
            <div className="space-y-3 md:space-y-6">
              <div>
                <h3 className="text-base md:text-lg font-bold mb-3 md:mb-4">Написать нам</h3>

                {/* Email */}
                <Card className="p-4 md:p-6 hover:shadow-lg transition-shadow mb-3 md:mb-4">
                  <div className="flex items-center gap-3 md:gap-4">
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-blue-500/10 dark:bg-blue-500/20 flex items-center justify-center">
                        <Mail className="w-5 h-5 md:w-6 md:h-6 text-blue-600 dark:text-blue-400" />
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs md:text-sm font-medium text-muted-foreground mb-0.5 md:mb-1">{t('contactForm.email')}</p>
                      <a
                        href={CONTACTS.emailHref}
                        className="text-sm md:text-lg font-semibold hover:text-primary transition-colors truncate block"
                      >
                        {CONTACTS.email}
                      </a>
                      <p className="text-xs text-muted-foreground mt-1 hidden md:block">Ответим в течение часа</p>
                    </div>
                  </div>
                </Card>

                <div className="space-y-2 md:space-y-4">
                  {/* WhatsApp */}
                  <Card className="p-3 md:p-6 hover:shadow-lg transition-all group cursor-pointer">
                    <a
                      href={CONTACTS.whatsapp}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 md:gap-4"
                    >
                      <div className="flex-shrink-0">
                        <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-green-500/10 dark:bg-green-500/20 flex items-center justify-center group-hover:bg-green-500/20 dark:group-hover:bg-green-500/30 transition-colors">
                          <MessageCircle className="w-5 h-5 md:w-6 md:h-6 text-green-600 dark:text-green-400" />
                        </div>
                      </div>
                      <div className="flex-1">
                        <p className="text-xs md:text-sm font-medium text-muted-foreground mb-0.5 md:mb-1">{t('contactsBlock.writeIn')}</p>
                        <p className="text-sm md:text-lg font-semibold group-hover:text-green-600 dark:group-hover:text-green-400 transition-colors">
                          WhatsApp
                        </p>
                      </div>
                      <div className="text-muted-foreground group-hover:text-green-600 dark:group-hover:text-green-400 transition-colors">
                        <svg className="w-5 h-5 md:w-6 md:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                      </div>
                    </a>
                  </Card>

                  {/* Telegram */}
                  <Card className="p-3 md:p-6 hover:shadow-lg transition-all group cursor-pointer">
                    <a
                      href={CONTACTS.telegram}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 md:gap-4"
                    >
                      <div className="flex-shrink-0">
                        <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-blue-500/10 dark:bg-blue-500/20 flex items-center justify-center group-hover:bg-blue-500/20 dark:group-hover:bg-blue-500/30 transition-colors">
                          <Send className="w-5 h-5 md:w-6 md:h-6 text-blue-600 dark:text-blue-400" />
                        </div>
                      </div>
                      <div className="flex-1">
                        <p className="text-xs md:text-sm font-medium text-muted-foreground mb-0.5 md:mb-1">{t('contactsBlock.writeIn')}</p>
                        <p className="text-sm md:text-lg font-semibold group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                          Telegram
                        </p>
                      </div>
                      <div className="text-muted-foreground group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                        <svg className="w-5 h-5 md:w-6 md:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                      </div>
                    </a>
                  </Card>
                </div>
              </div>
            </div>
          </div>

          {/* Альтернатива: форма заявки */}
          <div className="text-center pt-4 md:pt-8 border-t">
            <p className="text-sm md:text-base text-muted-foreground mb-3 md:mb-4">{t('contactsBlock.orLeaveRequest')}</p>
            <Button variant="outline" size="lg" asChild className="w-full md:w-auto">
              <Link href="/contacts#form">{t('contactsBlock.leaveRequest')}</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}

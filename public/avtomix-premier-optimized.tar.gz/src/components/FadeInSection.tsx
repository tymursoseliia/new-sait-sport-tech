'use client';

import { ReactNode } from 'react';

interface FadeInSectionProps {
  children: ReactNode;
  delay?: number;
  direction?: 'up' | 'down' | 'left' | 'right';
  className?: string;
}

export default function FadeInSection({
  children,
  className = '',
}: FadeInSectionProps) {
  return (
    <div className={className}>
      {children}
    </div>
  );
}

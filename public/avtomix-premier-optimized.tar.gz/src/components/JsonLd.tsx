import { CONTACTS } from '@/config/contacts';

export default function JsonLd() {
  const organizationSchema = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: CONTACTS.companyName,
    description: 'Профессиональный автопригон автомобилей из Европы в Россию',
    url: CONTACTS.website,
    logo: `${CONTACTS.website}/logo.png`,
    foundingDate: CONTACTS.foundingYear,
    address: {
      '@type': 'PostalAddress',
      streetAddress: CONTACTS.address,
      addressLocality: CONTACTS.city,
      postalCode: CONTACTS.postalCode,
      addressRegion: CONTACTS.region,
      addressCountry: 'RU',
    },
    contactPoint: {
      '@type': 'ContactPoint',
      telephone: CONTACTS.phone.replace(/[\s()-]/g, ''),
      contactType: 'customer service',
      email: CONTACTS.email,
      availableLanguage: 'Russian',
    },
    sameAs: [
      CONTACTS.whatsapp,
      CONTACTS.telegram,
    ],
  };

  const localBusinessSchema = {
    '@context': 'https://schema.org',
    '@type': 'LocalBusiness',
    name: CONTACTS.companyName,
    image: `${CONTACTS.website}/logo.png`,
    '@id': CONTACTS.website,
    url: CONTACTS.website,
    telephone: CONTACTS.phone.replace(/[\s()-]/g, ''),
    priceRange: '$',
    address: {
      '@type': 'PostalAddress',
      streetAddress: CONTACTS.address,
      addressLocality: CONTACTS.city,
      postalCode: CONTACTS.postalCode,
      addressRegion: CONTACTS.region,
      addressCountry: 'RU',
    },
    geo: {
      '@type': 'GeoCoordinates',
      latitude: CONTACTS.coordinates.lat,
      longitude: CONTACTS.coordinates.lng,
    },
    openingHoursSpecification: [
      {
        '@type': 'OpeningHoursSpecification',
        dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
        opens: '09:00',
        closes: '19:00',
      },
      {
        '@type': 'OpeningHoursSpecification',
        dayOfWeek: 'Saturday',
        opens: '10:00',
        closes: '16:00',
      },
    ],
    aggregateRating: {
      '@type': 'AggregateRating',
      ratingValue: '4.9',
      reviewCount: '500',
    },
  };

  const serviceSchema = {
    '@context': 'https://schema.org',
    '@type': 'Service',
    serviceType: 'Автопригон из Европы',
    provider: {
      '@type': 'Organization',
      name: CONTACTS.companyName,
    },
    areaServed: {
      '@type': 'Country',
      name: 'Россия',
    },
    hasOfferCatalog: {
      '@type': 'OfferCatalog',
      name: 'Услуги автопригона',
      itemListElement: [
        {
          '@type': 'Offer',
          itemOffered: {
            '@type': 'Service',
            name: 'Подбор автомобиля в Европе',
          },
        },
        {
          '@type': 'Offer',
          itemOffered: {
            '@type': 'Service',
            name: 'Проверка и диагностика',
          },
        },
        {
          '@type': 'Offer',
          itemOffered: {
            '@type': 'Service',
            name: 'Доставка и растаможка',
          },
        },
        {
          '@type': 'Offer',
          itemOffered: {
            '@type': 'Service',
            name: 'Постановка на учет',
          },
        },
      ],
    },
  };

  const websiteSchema = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: CONTACTS.companyName,
    url: CONTACTS.website,
    potentialAction: {
      '@type': 'SearchAction',
      target: `${CONTACTS.website}/catalog?search={search_term_string}`,
      'query-input': 'required name=search_term_string',
    },
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(localBusinessSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteSchema) }}
      />
    </>
  );
}

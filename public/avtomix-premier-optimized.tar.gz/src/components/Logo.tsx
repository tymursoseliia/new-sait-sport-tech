'use client';

import Link from 'next/link';
import Image from 'next/image';

export default function Logo() {
  return (
    <Link href="/" className="flex items-center">
      <Image
        src="https://ugc.same-assets.com/D69LZBrW5zr4b1E1nzzHZUrfkQHP7KoP.png"
        alt="AVTOMIX PREMIER"
        width={350}
        height={80}
        className="h-16 md:h-20 w-auto"
        priority
      />
    </Link>
  );
}

/**
 * Конфигурация Telegram бота для приема заявок
 *
 * Как настроить:
 * 1. Создайте бота через @BotFather в Telegram
 * 2. Получите токен бота
 * 3. Получите ваш Chat ID через @userinfobot
 * 4. Замените значения ниже на реальные
 */

export const TELEGRAM_CONFIG = {
  // Токен вашего бота (получите у @BotFather)
  // ВАЖНО: Храните токен в безопасности! В продакшене используйте переменные окружения
  botToken: process.env.TELEGRAM_BOT_TOKEN || '8246898693:AAEGPbkrclh-xGdK96IlR7utS7vTPw3a0tM',

  // Ваш Chat ID (получите у @userinfobot)
  chatId: process.env.TELEGRAM_CHAT_ID || '7552690430',

  // URL API Telegram
  apiUrl: 'https://api.telegram.org',
} as const;

/**
 * Проверка конфигурации
 */
export const isTelegramConfigured = (): boolean => {
  return (
    TELEGRAM_CONFIG.botToken !== 'ЗАМЕНИТЕ_НА_ВАШ_ТОКЕН_БОТА' &&
    TELEGRAM_CONFIG.chatId !== 'ЗАМЕНИТЕ_НА_ВАШ_CHAT_ID' &&
    TELEGRAM_CONFIG.botToken.length > 20
  );
};

/**
 * Форматирование сообщения для Telegram
 */
export const formatTelegramMessage = (data: {
  name: string;
  phone: string;
  email?: string;
  message?: string;
  carInterest?: string;
  source?: string;
}): string => {
  const timestamp = new Date().toLocaleString('ru-RU', {
    timeZone: 'Europe/Moscow',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });

  let message = `🚗 <b>Новая заявка с сайта</b>\n\n`;
  message += `📅 <b>Дата:</b> ${timestamp}\n\n`;
  message += `👤 <b>Имя:</b> ${data.name}\n`;
  message += `📞 <b>Телефон:</b> ${data.phone}\n`;

  if (data.email) {
    message += `📧 <b>Email:</b> ${data.email}\n`;
  }

  if (data.carInterest) {
    message += `🚙 <b>Интересует:</b> ${data.carInterest}\n`;
  }

  if (data.message) {
    message += `\n💬 <b>Сообщение:</b>\n${data.message}\n`;
  }

  if (data.source) {
    message += `\n📍 <b>Источник:</b> ${data.source}\n`;
  }

  message += `\n—————————————————\n`;
  message += `<i>AVTOMIX PREMIER - Система уведомлений</i>`;

  return message;
};

'use client';

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Language = 'ru' | 'en' | 'be';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>('ru');
  const [translations, setTranslations] = useState<Record<string, string>>({});

  useEffect(() => {
    // Загружаем сохраненный язык из localStorage
    const savedLang = localStorage.getItem('language') as Language;
    if (savedLang && ['ru', 'en', 'be'].includes(savedLang)) {
      setLanguageState(savedLang);
    }
  }, []);

  useEffect(() => {
    // Загружаем переводы для текущего языка
    import(`@/locales/${language}.json`)
      .then((module) => setTranslations(module.default))
      .catch((err) => console.error('Failed to load translations:', err));
  }, [language]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('language', lang);
  };

  const t = (key: string): string => {
    return translations[key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    // Return default values instead of throwing during SSR
    return {
      language: 'ru' as Language,
      setLanguage: () => {},
      t: (key: string) => key,
    };
  }
  return context;
}
